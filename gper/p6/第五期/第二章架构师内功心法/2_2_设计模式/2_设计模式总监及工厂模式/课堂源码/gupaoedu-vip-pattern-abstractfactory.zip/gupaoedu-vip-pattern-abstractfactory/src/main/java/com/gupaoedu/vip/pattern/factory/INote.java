package com.gupaoedu.vip.pattern.factory;

/**
 * 课堂笔记
 * Created by Tom.
 */
public interface INote {
    void edit();
}
