package com.gupaoedu.vip.pattern.factory;

/**
 * Created by Tom.
 */
public class PythonCourse implements ICourse {

    public void record() {
        System.out.println("录制Python课程");
    }
}
