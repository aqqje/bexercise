package com.gupaoedu.vip.pattern.flyweight.ticket;

public interface ITicket {
    void showInfo(String bunk);
}