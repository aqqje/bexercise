package com.gupaoedu.vip.pattern.singleton.test;

import com.gupaoedu.vip.pattern.singleton.register.ContainerSingleton;

/**
 * Created by Tom.
 */
public class Pojo {

}
