package com.chnmooc.syncftp.web.action;


import com.chnmooc.core.mvc.action.BaseAction;


//http://sync.chnmooc.com:8080/users@upload?script=1&domain=chnmooc.com
//@Controller
//@RequestMapping("/users@upload")
public class SyncAction extends BaseAction {
	
	/*
	@RequestMapping("")
	public ModelAndView upload(
			HttpServletRequest request,
			HttpServletResponse response,
			@RequestParam("upload") MultipartFile upfile){
		
		System.out.println(upfile);
		return null;
	}
	*/
}
