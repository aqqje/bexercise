package com.gupaoedu.vip.pattern.prototype.general;

/**
 * Created by Tom.
 */
public interface IPrototype<T> {
    T clone();
}
